import 'package:firebase_core/firebase_core.dart';

// Placeholder so the project compiles; run `flutterfire configure` to replace it
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    throw UnsupportedError(
      'Firebase is not configured. Run `flutterfire configure` (see README).',
    );
  }
}
